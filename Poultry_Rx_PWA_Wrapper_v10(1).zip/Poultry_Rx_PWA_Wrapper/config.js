window.POULTRY_RX_CONFIG = {
  // Replace this with the Apps Script Web App URL that ends in /exec.
  // Example: https://script.google.com/macros/s/DEPLOYMENT_ID/exec
  appUrl: "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE",
  appName: "Poultry Rx"
};
